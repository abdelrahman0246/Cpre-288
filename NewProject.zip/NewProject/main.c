/*
 * main.c
 *
 *  Created on: Apr 21, 2021
 *      Author: ammannan
 */
#include "Timer.h"
#include "lcd.h"
#include "cyBot_Scan.h"  // For scan sensors
#include "uart.h"
//
//// Uncomment or add any include directives that are needed
#include "open_interface.h"
#include "movement.h"
#include "button.h"
#include "uart.h"
#include "resetSimulation.h"

int main(void){

    timer_init(); // Must be called before lcd_init(), which uses timer functions
    lcd_init();
    uart_init();
    cyBOT_init_Scan();
    oi_t *sensor_data = oi_alloc();
    //oi_init(sensor_data);
    //resetSimulationBoard();
//    // YOUR CODE HERE
    cyBOT_Scan_t getScan;
    char c[50];
//
//
//
    //int j = 0;
    char data;

    //data = uart_receive();
    while (1)
        {
            data = uart_receive();
            oi_init(sensor_data);
            oi_update(sensor_data);
            ///This key moves the bot forward by 10 cm
            if (data == 'w')
            {
                char moveForward[] = "moving forward 30cm...\r\n";
                uart_sendStr(moveForward);
                //uart_sendChar('\r');
                move_forward(sensor_data, 100);
                //stop();


            }

            ///The bot will move CCW at 10 degrees
            else if (data == 'a')
            {
                //char turnLeft[] = "rotating counterclockwise 90 degrees...\r\n";
                //uart_sendStr(turnLeft) ;
                uart_sendChar('\r');
                turn_left(sensor_data,87);
                //stop();
            }



            ///Moves back by 10 cm
            else if (data == 's')
            {
                char moveBackward[] = "moving Backward 30cm...\r\n";
                uart_sendStr(moveBackward);
                //uart_sendChar('\r');
                move_backwards(sensor_data,100);
                //stop();
            }

            ///Rotates CW by 10 degrees
            else if (data == 'd')
            {
                //char turnRight[] = "rotating clockwise 90 degrees...\r\n";
                //uart_sendStr(turnRight) ;
                uart_sendChar('\r');
                turn_right(sensor_data,87);
                //stop();
            }



    free(sensor_data); // do this once at end of main()
    }
//free(sensor_data); // do this once at end of main()


}





