#include "lcd.h"
#include "open_interface.h"
#include "timer.h"

//double turn_left(oi_t *sensor_data, double degrees);
//double turn_right(oi_t *sensor_data, double degrees);
void turn_left(oi_t *sensor_data, int degrees);
void turn_right(oi_t *sensor_data, int degrees);
double move_backwards(oi_t *sensor_data, double distance_mm);
double move_forward(oi_t *sensor_data, double distance_mm);

double move_forward(oi_t *sensor_data, double distance_mm)
{

    double sum = 0;
    oi_setWheels(200, 200);
    while (sum < distance_mm)
    {

        //oi_update(sensor_data);
        oi_update(sensor_data);

        sum += sensor_data->distance;
    }
    oi_setWheels(0, 0);
    oi_free(sensor_data);
    return 0;
}

//double turn_left(oi_t *sensor_data, double degrees)
//{
//    double sum = 0;
//
//    degrees = -1.0 * degrees;
//    //oi_setWheels(-150, 150);
//
//    while (sum > degrees)
//    {
//        oi_update(sensor_data);
//        //oi_update(sensor_data);
//        //if(degrees - sum <= 5){
//        // turn_left(sensor_data, sum);
//
//        // }
//
//        sum += sensor_data->angle;
//    }
//    oi_setWheels(0, 0);
//    //oi_free(sensor_data);
//    return 0;
//
//}
void turn_left(oi_t *sensor_data, int degrees)   {
    int sum = 0;

    oi_setWheels(150, -150);

    while(sum < degrees) {
       oi_update(sensor_data);
       sum += sensor_data -> angle;
    }

    oi_setWheels(0,0); //stop
    oi_free(sensor_data);
}

//double turn_right(oi_t *sensor_data, double degrees)
//{
//    double sum = 0;
//    degrees = 1.0 * degrees;
//    oi_setWheels(150, -150);
//    while (sum > degrees)
//    {
//        oi_update(sensor_data);
//       // if (degrees + sum <= 5){
//         //       turnright(sensor_data, sum);
//    //}
//            sum -= sensor_data->angle;
//    }
//    oi_setWheels(0, 0);
//    //oi_free(sensor_data);
//    return 0;
//
//}

void turn_right(oi_t *sensor_data, int degrees)  {
    int sum = degrees;

    oi_setWheels(-150, 150);

    while(sum > 0) {
        oi_update(sensor_data);
        sum += sensor_data -> angle;
    }

    oi_setWheels(0,0); //stop
    oi_free(sensor_data);
}
double move_backwards(oi_t *sensor_data, double distance_mm)
{

    double sum = 0;
    oi_setWheels(-200, -200);
    while (sum < distance_mm)
    {

        oi_update(sensor_data);

        sum -= sensor_data->distance;
    }
    oi_setWheels(0, 0);
    //oi_free(sensor_data);
    return 0;
}

void stop()
{
 oi_setWheels(0,0);
}
